Locamarket IMAGE PROMPT PACK

12 category prompts + 42 product prompts = 54 total.

IMPORTANT: This ZIP contains a CSV manifest and a Claude/Codex instruction, NOT 54 actual image files.

Files:
- locamarket_image_manifest.csv : one image prompt and filename per item
- CLAUDE_CODE_INSTRUCTIONS.txt : automation prompt

AI generated images do not require Pexels API access, but a supported image generation tool/model is needed. Subscription to a coding assistant does not itself guarantee image generation. Branded product names are retained as mapping labels only; prompts avoid copying logos and official packaging.
